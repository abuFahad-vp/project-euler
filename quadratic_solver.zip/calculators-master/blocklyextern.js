/**
 * @fileoverview This is an externs file.
 * @externs
 */

let useBlockly = function(_callback, _lang)
{
  /* Nothing to be done in extern file */
};

